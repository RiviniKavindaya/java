public class Tree{
	int count=0;
	Object[] array;
	public Tree(){
		array =new Object[128];
	}
	public boolean empty(){
		return (array[1]==null);
		
	}
	public int left(int i)
	{
		return 2*i;
	}
	public int right(int i)
	{
		return 2*i+1;
	}
	public int parent(int i)
	{
		return i/2;
	}
	public Object getCargo(int i)
	{
		if(i<1||i>=array.length)
		{
			return null;
		}
		else{
			return array[i];
		}
		
	}
	public void setCargo(int i,Object obj)
	{
		
		if(i<1||i>=array.length)
		{ 
			
			return;
		}
		else{
			count++;
			array[i]=obj;
		}
	}
	public void printPreorder(int i)
	{
		if(getCargo(i)==null)
		{
			return;
		}
		System.out.println(getCargo(i));
		printPreorder(left(i));
		printPreorder(right(i));
	}
	public void printInorder(int i)
	{
		if(getCargo(i)==null)
		{
			return;
		}
		printInorder(left(i));
		System.out.println(getCargo(i));
		printInorder(right(i));
	}
	public void printPostOrder(int i)
	{
		if(getCargo(i)==null)
		{
			return;
		}
		printPostOrder(left(i));
		printPostOrder(right(i));
		System.out.println(getCargo(i));
	}
	public void member()
	{
		System.out.println( "number of nodes in the tree are "+count);
	}

	
	public static void main(String args[])
	{
		Tree tree=new Tree();
		int root=1;
		tree.setCargo(root,"cargo for root");
		tree.setCargo(tree.left(root),"cargo for left");
		tree.setCargo(tree.right(root),"cargo for right");
		
		tree.printPreorder(root);
		System.out.println();
		
		tree.printInorder(root);
		System.out.println();
		
		tree.printPostOrder(root);
		System.out.println();
		
		tree.member();
	}
}